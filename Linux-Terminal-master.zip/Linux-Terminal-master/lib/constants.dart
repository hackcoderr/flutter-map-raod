import 'package:flutter/material.dart';

const kPrimaryColor = Colors.red;
const kPrimaryLightColor = Colors.black;
