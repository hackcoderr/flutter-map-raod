package com.example.linux

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
