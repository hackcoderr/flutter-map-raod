# Linux Terminal
A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

Here is an overview of my app named "Linux Terminal" that provides all facilities of a Linux operating system's terminal. The user first has to login or signup in the app. While signing up the user has to input the Linux server IP to which he/she want to connect. 
In this app, the user will input the commands which he/she want to run on the Linux OS terminal. The command and output will not only display on the app but also store in Google Firebase Database.
